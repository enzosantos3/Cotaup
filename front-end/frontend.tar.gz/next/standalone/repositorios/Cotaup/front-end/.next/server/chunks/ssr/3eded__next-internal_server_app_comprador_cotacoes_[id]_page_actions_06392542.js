module.exports=[34759,(a,b,c)=>{}];

//# sourceMappingURL=3eded__next-internal_server_app_comprador_cotacoes_%5Bid%5D_page_actions_06392542.js.map