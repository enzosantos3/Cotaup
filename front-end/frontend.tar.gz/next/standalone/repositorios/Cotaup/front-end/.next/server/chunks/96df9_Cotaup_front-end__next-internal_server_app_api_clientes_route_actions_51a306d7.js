module.exports=[28294,(e,o,d)=>{}];

//# sourceMappingURL=96df9_Cotaup_front-end__next-internal_server_app_api_clientes_route_actions_51a306d7.js.map