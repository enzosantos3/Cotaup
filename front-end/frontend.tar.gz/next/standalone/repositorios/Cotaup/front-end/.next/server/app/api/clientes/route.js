var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/clientes/route.js")
R.c("server/chunks/[root-of-the-server]__4f0bb673._.js")
R.c("server/chunks/[root-of-the-server]__71a8d60d._.js")
R.c("server/chunks/7a841_next_ef6c0999._.js")
R.c("server/chunks/96df9_Cotaup_front-end__next-internal_server_app_api_clientes_route_actions_51a306d7.js")
R.m(49219)
module.exports=R.m(49219).exports
