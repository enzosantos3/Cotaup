module.exports=[33470,(a,b,c)=>{}];

//# sourceMappingURL=53288_front-end__next-internal_server_app_comprador_cotacoes_page_actions_897e7012.js.map