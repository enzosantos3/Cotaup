module.exports=[5725,(e,o,d)=>{}];

//# sourceMappingURL=53288_front-end__next-internal_server_app_api_fornecedores_route_actions_f405a330.js.map