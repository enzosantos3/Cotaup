module.exports=[98214,(e,o,d)=>{}];

//# sourceMappingURL=3eded__next-internal_server_app_api_produtoCotacao_%5Bid%5D_route_actions_223c50ea.js.map