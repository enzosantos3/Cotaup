module.exports=[54338,(e,o,d)=>{}];

//# sourceMappingURL=96df9_Cotaup_front-end__next-internal_server_app_favicon_ico_route_actions_e409ade5.js.map