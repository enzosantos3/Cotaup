var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/cotacoes/listar/abertas/route.js")
R.c("server/chunks/[root-of-the-server]__abd54343._.js")
R.c("server/chunks/[root-of-the-server]__71a8d60d._.js")
R.c("server/chunks/7a841_next_ef6c0999._.js")
R.c("server/chunks/3eded__next-internal_server_app_api_cotacoes_listar_abertas_route_actions_de17dcc0.js")
R.m(39886)
module.exports=R.m(39886).exports
