module.exports=[17467,(a,b,c)=>{}];

//# sourceMappingURL=f62e7_server_app_fornecedor_clientes_detalhes_%5Bid%5D_page_actions_dafa5957.js.map