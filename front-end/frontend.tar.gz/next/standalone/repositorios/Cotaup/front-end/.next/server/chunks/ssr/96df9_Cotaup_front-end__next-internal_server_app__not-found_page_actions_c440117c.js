module.exports=[15094,(a,b,c)=>{}];

//# sourceMappingURL=96df9_Cotaup_front-end__next-internal_server_app__not-found_page_actions_c440117c.js.map