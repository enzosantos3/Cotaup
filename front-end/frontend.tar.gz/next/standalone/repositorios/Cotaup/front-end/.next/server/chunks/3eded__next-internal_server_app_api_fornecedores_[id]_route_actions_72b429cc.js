module.exports=[74045,(e,o,d)=>{}];

//# sourceMappingURL=3eded__next-internal_server_app_api_fornecedores_%5Bid%5D_route_actions_72b429cc.js.map