module.exports=[3067,(a,b,c)=>{}];

//# sourceMappingURL=96df9_Cotaup_front-end__next-internal_server_app_pedidos_page_actions_2fbd88e4.js.map