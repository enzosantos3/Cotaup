module.exports=[72552,(a,b,c)=>{}];

//# sourceMappingURL=3eded__next-internal_server_app_fornecedor_marketplace_page_actions_f886beea.js.map