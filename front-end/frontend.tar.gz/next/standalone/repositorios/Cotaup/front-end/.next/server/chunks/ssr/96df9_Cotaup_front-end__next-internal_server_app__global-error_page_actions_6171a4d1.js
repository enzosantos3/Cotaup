module.exports=[52720,(a,b,c)=>{}];

//# sourceMappingURL=96df9_Cotaup_front-end__next-internal_server_app__global-error_page_actions_6171a4d1.js.map