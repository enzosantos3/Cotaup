module.exports=[9240,(e,o,d)=>{}];

//# sourceMappingURL=3eded__next-internal_server_app_api_cotacoes_listar_abertas_route_actions_de17dcc0.js.map