var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/produtos/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__e3a83872._.js")
R.c("server/chunks/[root-of-the-server]__71a8d60d._.js")
R.c("server/chunks/7a841_next_ef6c0999._.js")
R.c("server/chunks/53288_front-end__next-internal_server_app_api_produtos_[id]_route_actions_8ae92fca.js")
R.m(612)
module.exports=R.m(612).exports
