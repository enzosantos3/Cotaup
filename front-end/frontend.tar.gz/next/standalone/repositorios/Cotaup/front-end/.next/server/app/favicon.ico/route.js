var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/7a841_next_ef6c0999._.js")
R.c("server/chunks/[root-of-the-server]__71a8d60d._.js")
R.c("server/chunks/7a841_next_dist_esm_build_templates_app-route_4d868cd0.js")
R.c("server/chunks/96df9_Cotaup_front-end__next-internal_server_app_favicon_ico_route_actions_e409ade5.js")
R.m(55761)
module.exports=R.m(55761).exports
