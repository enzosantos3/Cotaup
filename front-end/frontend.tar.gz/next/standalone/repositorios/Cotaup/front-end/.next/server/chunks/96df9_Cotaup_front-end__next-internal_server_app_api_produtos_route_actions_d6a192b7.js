module.exports=[35525,(e,o,d)=>{}];

//# sourceMappingURL=96df9_Cotaup_front-end__next-internal_server_app_api_produtos_route_actions_d6a192b7.js.map