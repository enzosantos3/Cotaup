var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/produtos/route.js")
R.c("server/chunks/[root-of-the-server]__cbe4ff9e._.js")
R.c("server/chunks/[root-of-the-server]__71a8d60d._.js")
R.c("server/chunks/7a841_next_ef6c0999._.js")
R.c("server/chunks/96df9_Cotaup_front-end__next-internal_server_app_api_produtos_route_actions_d6a192b7.js")
R.m(99708)
module.exports=R.m(99708).exports
