globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/09d19ad088edc556.js",
    "static/chunks/ba5e4b768a33aa2f.js",
    "static/chunks/457a2f0b58d57259.js",
    "static/chunks/8b2386c950f87139.js",
    "static/chunks/0f003a197f687121.js",
    "static/chunks/turbopack-c605b6531b3490c9.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];