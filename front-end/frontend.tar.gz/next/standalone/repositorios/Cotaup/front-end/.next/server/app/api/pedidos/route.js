var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/pedidos/route.js")
R.c("server/chunks/[root-of-the-server]__77e100bc._.js")
R.c("server/chunks/[root-of-the-server]__71a8d60d._.js")
R.c("server/chunks/96df9_Cotaup_front-end__next-internal_server_app_api_pedidos_route_actions_1ca34184.js")
R.m(16115)
module.exports=R.m(16115).exports
