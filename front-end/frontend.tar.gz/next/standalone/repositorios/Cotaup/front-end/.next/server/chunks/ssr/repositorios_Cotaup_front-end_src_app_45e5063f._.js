module.exports=[49135,a=>{a.v("/_next/static/media/favicon.347d1d13.ico")},52062,a=>{"use strict";let b={src:a.i(49135).default,width:1741,height:1977};a.s(["default",0,b])}];

//# sourceMappingURL=repositorios_Cotaup_front-end_src_app_45e5063f._.js.map