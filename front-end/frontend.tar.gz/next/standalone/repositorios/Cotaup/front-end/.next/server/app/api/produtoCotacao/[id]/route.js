var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/produtoCotacao/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__c29a6dd8._.js")
R.c("server/chunks/[root-of-the-server]__71a8d60d._.js")
R.c("server/chunks/7a841_next_ef6c0999._.js")
R.c("server/chunks/3eded__next-internal_server_app_api_produtoCotacao_[id]_route_actions_223c50ea.js")
R.m(34484)
module.exports=R.m(34484).exports
