module.exports=[75421,(a,b,c)=>{}];

//# sourceMappingURL=3eded__next-internal_server_app_comprador_fornecedores_page_actions_c20013e4.js.map