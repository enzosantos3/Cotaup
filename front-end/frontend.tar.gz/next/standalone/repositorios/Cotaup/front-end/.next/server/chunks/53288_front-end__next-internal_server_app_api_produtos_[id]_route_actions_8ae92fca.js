module.exports=[99004,(e,o,d)=>{}];

//# sourceMappingURL=53288_front-end__next-internal_server_app_api_produtos_%5Bid%5D_route_actions_8ae92fca.js.map