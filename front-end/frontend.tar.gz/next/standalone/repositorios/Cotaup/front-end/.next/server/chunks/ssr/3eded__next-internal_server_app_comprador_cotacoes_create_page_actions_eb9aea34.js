module.exports=[48083,(a,b,c)=>{}];

//# sourceMappingURL=3eded__next-internal_server_app_comprador_cotacoes_create_page_actions_eb9aea34.js.map