module.exports=[72601,(a,b,c)=>{}];

//# sourceMappingURL=96df9_Cotaup_front-end__next-internal_server_app_produtos_page_actions_1eb3edf4.js.map