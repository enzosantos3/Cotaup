var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cotacoes/route.js")
R.c("server/chunks/[root-of-the-server]__1aab7f06._.js")
R.c("server/chunks/[root-of-the-server]__71a8d60d._.js")
R.c("server/chunks/7a841_next_ef6c0999._.js")
R.c("server/chunks/96df9_Cotaup_front-end__next-internal_server_app_api_cotacoes_route_actions_be2f8fcc.js")
R.m(15985)
module.exports=R.m(15985).exports
