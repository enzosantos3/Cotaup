module.exports=[4049,(e,o,d)=>{}];

//# sourceMappingURL=53288_front-end__next-internal_server_app_api_cotacoes_%5Bid%5D_route_actions_5603e417.js.map