module.exports=[70009,a=>{"use strict";var b=a.i(65679);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c,"metadata",0,{title:"Login - CotaUp",description:"Acesse sua conta CotaUp"}])}];

//# sourceMappingURL=repositorios_Cotaup_front-end_src_app_login_layout_tsx_09b31ef3._.js.map