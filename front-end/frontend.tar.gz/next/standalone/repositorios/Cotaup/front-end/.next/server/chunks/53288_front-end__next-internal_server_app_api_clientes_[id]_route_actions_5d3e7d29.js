module.exports=[19607,(e,o,d)=>{}];

//# sourceMappingURL=53288_front-end__next-internal_server_app_api_clientes_%5Bid%5D_route_actions_5d3e7d29.js.map