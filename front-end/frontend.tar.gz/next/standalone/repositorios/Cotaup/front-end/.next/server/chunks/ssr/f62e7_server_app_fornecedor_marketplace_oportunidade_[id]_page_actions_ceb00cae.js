module.exports=[1220,(a,b,c)=>{}];

//# sourceMappingURL=f62e7_server_app_fornecedor_marketplace_oportunidade_%5Bid%5D_page_actions_ceb00cae.js.map