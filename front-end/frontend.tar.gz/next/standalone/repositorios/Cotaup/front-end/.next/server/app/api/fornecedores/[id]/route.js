var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/fornecedores/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__9d5cd268._.js")
R.c("server/chunks/[root-of-the-server]__71a8d60d._.js")
R.c("server/chunks/7a841_next_ef6c0999._.js")
R.c("server/chunks/3eded__next-internal_server_app_api_fornecedores_[id]_route_actions_72b429cc.js")
R.m(34542)
module.exports=R.m(34542).exports
