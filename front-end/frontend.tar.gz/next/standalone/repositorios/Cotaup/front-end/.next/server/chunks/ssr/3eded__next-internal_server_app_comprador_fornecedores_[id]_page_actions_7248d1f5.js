module.exports=[60141,(a,b,c)=>{}];

//# sourceMappingURL=3eded__next-internal_server_app_comprador_fornecedores_%5Bid%5D_page_actions_7248d1f5.js.map