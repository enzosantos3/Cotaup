var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/produto-cotacao/listar/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__ffb1c228._.js")
R.c("server/chunks/[root-of-the-server]__71a8d60d._.js")
R.c("server/chunks/7a841_next_ef6c0999._.js")
R.c("server/chunks/8a955_next-internal_server_app_api_produto-cotacao_listar_[id]_route_actions_c35271e7.js")
R.m(65918)
module.exports=R.m(65918).exports
