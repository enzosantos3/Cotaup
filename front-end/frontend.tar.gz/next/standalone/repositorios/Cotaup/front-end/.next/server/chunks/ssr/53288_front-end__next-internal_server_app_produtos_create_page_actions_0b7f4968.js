module.exports=[70256,(a,b,c)=>{}];

//# sourceMappingURL=53288_front-end__next-internal_server_app_produtos_create_page_actions_0b7f4968.js.map