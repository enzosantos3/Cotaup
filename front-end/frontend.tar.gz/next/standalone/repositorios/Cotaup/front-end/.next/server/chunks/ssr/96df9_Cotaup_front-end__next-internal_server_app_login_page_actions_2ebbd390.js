module.exports=[52865,(a,b,c)=>{}];

//# sourceMappingURL=96df9_Cotaup_front-end__next-internal_server_app_login_page_actions_2ebbd390.js.map