module.exports=[66462,(e,o,d)=>{}];

//# sourceMappingURL=96df9_Cotaup_front-end__next-internal_server_app_api_cotacoes_route_actions_be2f8fcc.js.map