var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/fornecedores/route.js")
R.c("server/chunks/[root-of-the-server]__72798a75._.js")
R.c("server/chunks/[root-of-the-server]__71a8d60d._.js")
R.c("server/chunks/7a841_next_ef6c0999._.js")
R.c("server/chunks/53288_front-end__next-internal_server_app_api_fornecedores_route_actions_f405a330.js")
R.m(18237)
module.exports=R.m(18237).exports
