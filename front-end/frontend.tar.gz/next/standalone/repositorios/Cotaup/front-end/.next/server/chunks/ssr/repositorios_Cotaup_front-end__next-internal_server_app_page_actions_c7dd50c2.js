module.exports=[41021,(a,b,c)=>{}];

//# sourceMappingURL=repositorios_Cotaup_front-end__next-internal_server_app_page_actions_c7dd50c2.js.map