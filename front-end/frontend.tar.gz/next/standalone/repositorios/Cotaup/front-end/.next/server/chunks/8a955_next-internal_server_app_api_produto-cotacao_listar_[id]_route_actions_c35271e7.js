module.exports=[37336,(e,o,d)=>{}];

//# sourceMappingURL=8a955_next-internal_server_app_api_produto-cotacao_listar_%5Bid%5D_route_actions_c35271e7.js.map