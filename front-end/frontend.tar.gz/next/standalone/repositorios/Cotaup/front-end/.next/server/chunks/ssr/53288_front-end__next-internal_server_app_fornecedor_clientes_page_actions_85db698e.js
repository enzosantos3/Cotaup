module.exports=[65336,(a,b,c)=>{}];

//# sourceMappingURL=53288_front-end__next-internal_server_app_fornecedor_clientes_page_actions_85db698e.js.map