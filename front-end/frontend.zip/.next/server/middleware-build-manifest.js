globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/fbfabe0b7707566d.js",
    "static/chunks/248cba0fcb3874ed.js",
    "static/chunks/a92b6a2da18471af.js",
    "static/chunks/023d923a37d494fc.js",
    "static/chunks/9188a64d1317f567.js",
    "static/chunks/turbopack-a2b5132d17e9842f.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];