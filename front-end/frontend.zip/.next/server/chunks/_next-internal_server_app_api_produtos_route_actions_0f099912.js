module.exports=[69034,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_produtos_route_actions_0f099912.js.map