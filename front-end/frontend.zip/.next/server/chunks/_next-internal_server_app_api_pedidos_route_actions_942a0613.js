module.exports=[8448,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pedidos_route_actions_942a0613.js.map