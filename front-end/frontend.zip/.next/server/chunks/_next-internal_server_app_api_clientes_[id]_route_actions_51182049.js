module.exports=[97700,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_clientes_%5Bid%5D_route_actions_51182049.js.map