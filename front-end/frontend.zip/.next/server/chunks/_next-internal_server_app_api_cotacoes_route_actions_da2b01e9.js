module.exports=[64454,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cotacoes_route_actions_da2b01e9.js.map