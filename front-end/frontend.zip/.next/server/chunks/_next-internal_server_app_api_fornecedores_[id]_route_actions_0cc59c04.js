module.exports=[11546,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_fornecedores_%5Bid%5D_route_actions_0cc59c04.js.map