module.exports=[35795,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_produtos_%5Bid%5D_route_actions_c123bf0d.js.map