module.exports=[44288,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_fornecedor_clientes_detalhes_%5Bid%5D_page_actions_a9122a0a.js.map