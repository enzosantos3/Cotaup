module.exports=[90449,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_comprador_pedidos_page_actions_c9c38cd8.js.map