module.exports=[50025,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fornecedor_dashboard_page_actions_9042edaa.js.map