module.exports=[26796,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_comprador_cotacoes_page_actions_be9357ce.js.map