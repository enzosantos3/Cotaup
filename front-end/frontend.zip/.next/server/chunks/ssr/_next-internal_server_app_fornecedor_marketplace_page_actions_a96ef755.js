module.exports=[53714,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fornecedor_marketplace_page_actions_a96ef755.js.map