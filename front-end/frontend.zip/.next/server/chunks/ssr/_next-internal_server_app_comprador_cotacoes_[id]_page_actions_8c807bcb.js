module.exports=[76767,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_comprador_cotacoes_%5Bid%5D_page_actions_8c807bcb.js.map