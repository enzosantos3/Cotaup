module.exports=[86398,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fornecedor_produtos_page_actions_4a7ea314.js.map