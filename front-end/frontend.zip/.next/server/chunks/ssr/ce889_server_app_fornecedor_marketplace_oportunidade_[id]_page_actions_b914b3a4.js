module.exports=[65582,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_fornecedor_marketplace_oportunidade_%5Bid%5D_page_actions_b914b3a4.js.map