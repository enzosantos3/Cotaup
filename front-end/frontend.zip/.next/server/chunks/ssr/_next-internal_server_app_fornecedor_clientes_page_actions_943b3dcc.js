module.exports=[64720,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fornecedor_clientes_page_actions_943b3dcc.js.map