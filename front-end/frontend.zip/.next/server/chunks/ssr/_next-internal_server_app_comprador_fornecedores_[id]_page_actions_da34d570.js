module.exports=[71170,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_comprador_fornecedores_%5Bid%5D_page_actions_da34d570.js.map