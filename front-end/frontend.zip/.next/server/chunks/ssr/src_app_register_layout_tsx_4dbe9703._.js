module.exports=[48579,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c,"metadata",0,{title:"Register - CotaUp",description:"Crie sua conta CotaUp"}])}];

//# sourceMappingURL=src_app_register_layout_tsx_4dbe9703._.js.map