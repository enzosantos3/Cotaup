module.exports=[86568,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fornecedor_produtos_%5Bid%5D_page_actions_e1741ef2.js.map