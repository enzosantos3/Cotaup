module.exports=[62853,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_comprador_produtos_page_actions_708c80ae.js.map