module.exports=[67357,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c,"metadata",0,{title:"Login - CotaUp",description:"Acesse sua conta CotaUp"}])}];

//# sourceMappingURL=src_app_login_layout_tsx_00de0b26._.js.map