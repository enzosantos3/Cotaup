module.exports=[3025,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fornecedor_produtos_create_page_actions_6b9e51f4.js.map