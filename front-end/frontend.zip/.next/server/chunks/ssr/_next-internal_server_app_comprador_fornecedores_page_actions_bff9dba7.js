module.exports=[49095,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_comprador_fornecedores_page_actions_bff9dba7.js.map