module.exports=[6855,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fornecedor_pedidos_page_actions_cfab6f33.js.map