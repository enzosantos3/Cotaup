module.exports=[72704,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_comprador_cotacoes_create_page_actions_e26e418f.js.map