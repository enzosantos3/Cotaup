module.exports=[5625,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_produtoCotacao_%5Bid%5D_route_actions_c03aa235.js.map