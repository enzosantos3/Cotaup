module.exports=[63612,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_produto-cotacao_listar_%5Bid%5D_route_actions_39aab729.js.map