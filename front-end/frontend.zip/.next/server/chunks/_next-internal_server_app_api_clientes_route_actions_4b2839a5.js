module.exports=[80401,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_clientes_route_actions_4b2839a5.js.map