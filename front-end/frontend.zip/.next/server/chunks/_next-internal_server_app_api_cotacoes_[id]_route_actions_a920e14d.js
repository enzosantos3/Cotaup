module.exports=[77521,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cotacoes_%5Bid%5D_route_actions_a920e14d.js.map