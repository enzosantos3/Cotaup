module.exports=[64858,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cotacoes_listar_abertas_route_actions_5b34bf5e.js.map