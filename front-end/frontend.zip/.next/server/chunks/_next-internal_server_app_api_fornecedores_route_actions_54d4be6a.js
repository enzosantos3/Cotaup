module.exports=[24865,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_fornecedores_route_actions_54d4be6a.js.map