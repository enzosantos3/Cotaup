var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/pedidos/route.js")
R.c("server/chunks/[root-of-the-server]__31fb679b._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_pedidos_route_actions_942a0613.js")
R.m(54684)
module.exports=R.m(54684).exports
