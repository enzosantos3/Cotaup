var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/produtos/route.js")
R.c("server/chunks/[root-of-the-server]__88491345._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_0700e68e._.js")
R.c("server/chunks/_next-internal_server_app_api_produtos_route_actions_0f099912.js")
R.m(11500)
module.exports=R.m(11500).exports
