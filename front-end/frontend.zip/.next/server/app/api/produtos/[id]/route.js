var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/produtos/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__5e958618._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_0700e68e._.js")
R.c("server/chunks/_next-internal_server_app_api_produtos_[id]_route_actions_c123bf0d.js")
R.m(8988)
module.exports=R.m(8988).exports
