var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/cotacoes/listar/abertas/route.js")
R.c("server/chunks/[root-of-the-server]__90f0192b._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_0700e68e._.js")
R.c("server/chunks/_next-internal_server_app_api_cotacoes_listar_abertas_route_actions_5b34bf5e.js")
R.m(6231)
module.exports=R.m(6231).exports
