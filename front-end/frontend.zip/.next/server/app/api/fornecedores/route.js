var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/fornecedores/route.js")
R.c("server/chunks/[root-of-the-server]__7b939bc8._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_0700e68e._.js")
R.c("server/chunks/_next-internal_server_app_api_fornecedores_route_actions_54d4be6a.js")
R.m(83413)
module.exports=R.m(83413).exports
