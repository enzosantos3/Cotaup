var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/fornecedores/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__bf76b6f3._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_0700e68e._.js")
R.c("server/chunks/_next-internal_server_app_api_fornecedores_[id]_route_actions_0cc59c04.js")
R.m(72907)
module.exports=R.m(72907).exports
